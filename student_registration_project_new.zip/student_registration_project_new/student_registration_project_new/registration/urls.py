from django.urls import path
from .views import course_list, course_detail, add_project, project_list, StudentListView, StudentDetailView, home

urlpatterns = [
    path('', home, name='home'),
    path('courses/', course_list, name='course_list'),
    path('courses/<int:course_id>/', course_detail, name='course_detail'),
    path('projects/', project_list, name='project_list'),
    path('projects/add/', add_project, name='add_project'),
    path('students/', StudentListView.as_view(), name='student_list'),
    path('students/<int:pk>/', StudentDetailView.as_view(), name='student_detail'),
]
