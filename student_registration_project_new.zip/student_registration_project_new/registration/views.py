from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView
from .models import Student, Course, Project, Enrollment
from .forms import ProjectForm
def student_list(request):
    students = Student.objects.all()
    if request.method == 'POST':
        # Handle form submission for adding a new student
        name = request.POST.get('name')
        email = request.POST.get('email')
        new_student = Student.objects.create(name=name, email=email)
        return redirect('student_list')  # Redirect to student list after adding

    return render(request, 'student_list.html', {'students': students})

def course_list(request):
    courses = Course.objects.all()
    if request.method == 'POST':
        # Handle form submission for adding a new course
        title = request.POST.get('title')
        description = request.POST.get('description')
        new_course = Course.objects.create(title=title, description=description)
        return redirect('course_list')  # Redirect to course list after adding

    return render(request, 'course_list.html', {'courses': courses})

def project_list(request):
    projects = Project.objects.all()
    if request.method == 'POST':
        # Handle form submission for adding a new project
        student_id = request.POST.get('student')
        topic = request.POST.get('topic')
        languages = request.POST.get('languages')
        duration = request.POST.get('duration')
        new_project = Project.objects.create(student_id=student_id, topic=topic, languages=languages, duration=duration)
        return redirect('project_list')  # Redirect to project list after adding

    form = ProjectForm()
    return render(request, 'project_list.html', {'projects': projects, 'form': form})
def course_list(request):
    courses = Course.objects.all()
    return render(request, 'course_list.html', {'courses': courses})

def course_detail(request, course_id):
    course = get_object_or_404(Course, pk=course_id)
    students = Student.objects.all()  # Fetch all students

    if request.method == 'POST':
        student_id = request.POST.get('student_id')
        student = get_object_or_404(Student, pk=student_id)
        Enrollment.objects.create(student=student, course=course)
        return redirect('course_detail', course_id=course_id)

    return render(request, 'course_detail.html', {'course': course, 'students': students})

def add_project(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('project_list')
    else:
        form = ProjectForm()
    return render(request, 'add_project.html', {'form': form})

def project_list(request):
    projects = Project.objects.all()
    return render(request, 'project_list.html', {'projects': projects})

def home(request):
    return render(request, 'home.html')

class StudentListView(ListView):
    model = Student
    template_name = 'student_list.html'
    context_object_name = 'students'

class StudentDetailView(DetailView):
    model = Student
    template_name = 'student_detail.html'
    context_object_name = 'student'
