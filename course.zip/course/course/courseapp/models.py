from django.db import models

# Create your models here.

class stud(models.Model):
    fname=models.CharField(max_length=50)
    lname=models.CharField(max_length=50)
    email = models.EmailField('e-mail',unique=True)
    def __str__(self):
        return "%s %s %s" % (self.fname,self.email,self.lname)


class course(models.Model):
    cname=models.CharField(max_length=50)
    students = models.ManyToManyField(stud, related_name='courses')
    def __str__(self):
        return"%s" %(self.cname)