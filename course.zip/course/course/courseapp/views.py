from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404, redirect

from .models import stud,course

def course_list(request):
    courses = course.objects.all()
    return render(request,'course_list.html', {'courses': courses})

def course_detail(request, course_id):
    courseb = get_object_or_404(course, id=course_id)
    students = courseb.students.all()
    return render(request, 'course_detail.html', {'course': courseb, 'students': students})

def student_register(request, course_id):
    courseb = get_object_or_404(course, id=course_id)
    #courseb=course.objects.get(id=course_id)
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')

        if fname and lname and email:
            student,created = stud.objects.get_or_create(email=email,defaults={'fname': fname, 'lname': lname})
            courseb.students.add(student)
            return redirect('course_detail', course_id=courseb.id)
    return render(request, 'student_register.html', {'course': courseb})
