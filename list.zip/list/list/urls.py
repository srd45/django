from django.contrib import admin
from django.urls import path
from list_app.views import showlist
urlpatterns = [
path('admin/', admin.site.urls),
path('showlist/', showlist),
path('', showlist), # Redirect root URL to showlist
]