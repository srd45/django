from django.db import models

# Create your models here.
class CurrentDateTime(models.Model):
 current_date_time = models.DateTimeField(auto_now_add=True)
