# courseapp/views.py
from django.shortcuts import render, redirect, get_object_or_404
from .models import Student, Course, Project
from .forms import CourseForm, ProjectForm, StudentForm  # Ensure StudentForm is imported
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

def home(request):
    students = Student.objects.all()
    courses = Course.objects.all()  # Add this line to fetch courses
    projects = Project.objects.all()  # Add this line to fetch projects
    return render(request, 'courseapp/home.html', {'students': students, 'courses': courses, 'projects': projects})

def student_registration(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            student = form.save()
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        form = StudentForm()
    return render(request, 'courseapp/register_student.html', {'form': form})

def add_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')  # Redirect to the homepage after adding a course
    else:
        form = CourseForm()
    return render(request, 'courseapp/add_course.html', {'form': form})

def add_project(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')  # Redirect to the homepage after adding a project
    else:
        form = ProjectForm()
    return render(request, 'courseapp/add_project.html', {'form': form})

def course_student_list(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    students = course.students.all()
    return render(request, 'courseapp/course_student_list.html', {'course': course, 'students': students})

def project_student_list(request, pk):
    # Your view logic here
    project = Project.objects.get(pk=pk)
    students = project.students.all()  # Assuming a ManyToManyField or ForeignKey relation
    
    context = {
        'project': project,
        'students': students,
    }
    return render(request, 'courseapp/project_student_list.html', context)


def project_detail(request, pk):
    project = get_object_or_404(Project, pk=pk)
    context = {
        'project': project,
    }
    return render(request, 'courseapp/project_detail.html', context)

@csrf_exempt  # Use csrf_exempt if CSRF protection is enabled and you want to exempt this view from CSRF checks
def search_students(request):
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        query = request.GET.get('query', '')
        students = Student.objects.filter(first_name__icontains=query) | Student.objects.filter(last_name__icontains=query)
        
        results = []
        for student in students:
            student_data = {
                'id': student.id,
                'name': f"{student.first_name} {student.last_name}",
                'email': student.email,
                'courses': [course.name for course in student.courses.all()]
            }
            results.append(student_data)
        
        return JsonResponse({'results': results})
    
    return render(request, 'courseapp/search.html')