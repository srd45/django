# courseapp/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('add_course/', views.add_course, name='add_course'),
    path('add_project/', views.add_project, name='add_project'),
    path('register/', views.register_student, name='register_student'),
    path('course/<int:course_id>/students/', views.course_student_list, name='course_student_list'),
    path('projects/<int:pk>/', views.project_detail, name='project_detail'),
]
